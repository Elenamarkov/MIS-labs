import 'package:flutter/material.dart';
import '../models/event.dart';
import '../screens/map_screen.dart';

class HomeScreen extends StatelessWidget {
  // Sample data for events
  final List<Event> events = [
    Event(
      title: 'Math Exam',
      dateTime: DateTime(2024, 12, 29, 10, 0),
      location: 'Room 101, University A',
      latitude: 41.9981,
      longitude: 21.4254,
    ),
    Event(
      title: 'Science Exam',
      dateTime: DateTime(2024, 12, 30, 14, 0),
      location: 'Room 202, University B',
      latitude: 42.0011,
      longitude: 21.4254,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Exam Schedule')),
      body: ListView.builder(
        itemCount: events.length,
        itemBuilder: (context, index) {
          final event = events[index];
          return ListTile(
            title: Text(event.title),
            subtitle: Text('${event.dateTime} - ${event.location}'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => MapScreen(
                    latitude: event.latitude,
                    longitude: event.longitude,
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
