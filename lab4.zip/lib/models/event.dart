class Event {
  String title;
  DateTime dateTime;
  String location;
  double latitude;
  double longitude;

  Event({
    required this.title,
    required this.dateTime,
    required this.location,
    required this.latitude,
    required this.longitude,
  });
}
