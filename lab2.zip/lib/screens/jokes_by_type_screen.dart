import 'package:flutter/material.dart';

class JokesByTypeScreen extends StatelessWidget {
  final String jokeType;

  const JokesByTypeScreen({Key? key, required this.jokeType}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Jokes: $jokeType'),
      ),
      body: Center(
        child: Text('List of jokes for type: $jokeType'),
      ),
    );
  }
}
