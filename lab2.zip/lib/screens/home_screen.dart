import 'package:flutter/material.dart';
import '../services/api_services.dart';
import '../widgets/joke_card.dart';
import '../models/joke_type.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<List<JokeType>> _jokeTypes;

  @override
  void initState() {
    super.initState();
    _jokeTypes = ApiServices.fetchJokeTypes();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Joke Categories"),
        actions: [
          IconButton(
            icon: const Icon(Icons.lightbulb),
            onPressed: () async {
              final joke = await ApiServices.fetchRandomJoke();
              Navigator.pushNamed(context, '/randomJoke', arguments: joke);
            },
          ),
        ],
      ),
      body: FutureBuilder<List<JokeType>>(
        future: _jokeTypes,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return const Center(child: Text("Error loading joke types"));
          } else {
            final types = snapshot.data!;
            return ListView.builder(
              itemCount: types.length,
              itemBuilder: (context, index) {
                return JokeCard(jokeType: types[index]);
              },
            );
          }
        },
      ),
    );
  }
}
