import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/joke.dart';
import '../models/joke_type.dart';

class ApiServices {
  static Future<List<JokeType>> fetchJokeTypes() async {
    final response = await http
        .get(Uri.parse('https://official-joke-api.appspot.com/types'));
    if (response.statusCode == 200) {
      final List<dynamic> data = jsonDecode(response.body);
      return data.map((type) => JokeType(type: type)).toList();
    } else {
      throw Exception('Failed to load joke types');
    }
  }

  static Future<Joke> fetchRandomJoke() async {
    final response = await http
        .get(Uri.parse('https://official-joke-api.appspot.com/random_joke'));
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return Joke(setup: data['setup'], punchline: data['punchline']);
    } else {
      throw Exception('Failed to load random joke');
    }
  }
}
