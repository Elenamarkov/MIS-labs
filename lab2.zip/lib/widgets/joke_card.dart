import 'package:flutter/material.dart';
import '../models/joke_type.dart';

class JokeCard extends StatelessWidget {
  final JokeType jokeType;

  const JokeCard({Key? key, required this.jokeType}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      child: ListTile(
        title: Text(
          jokeType.type,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        trailing: const Icon(Icons.arrow_forward),
        onTap: () {
          // Navigate to the JokesByTypeScreen with the selected joke type
          Navigator.pushNamed(
            context,
            '/jokesByType',
            arguments: jokeType.type,
          );
        },
      ),
    );
  }
}
