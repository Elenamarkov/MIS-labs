import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/jokes_by_type_screen.dart';
import 'screens/random_joke_screen.dart';
import 'models/joke.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Random Jokes App',
      routes: {
        '/': (context) => const HomeScreen(),
        '/jokesByType': (context) => JokesByTypeScreen(
            jokeType: 'general'), // Поправено: ставено вредност за jokeType
        '/randomJoke': (context) => RandomJokeScreen(
            joke: Joke(
                setup: 'Why did the chicken cross the road?',
                punchline:
                    'To get to the other side.')), // Поправено: ставени дефолтни вредности
      },
      initialRoute: '/',
    );
  }
}
