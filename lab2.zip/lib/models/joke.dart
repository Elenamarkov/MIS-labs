class Joke {
  final String setup;
  final String punchline;

  Joke({required this.setup, required this.punchline});
}
