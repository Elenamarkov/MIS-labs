class JokeType {
  final String type;

  JokeType({required this.type});
}
