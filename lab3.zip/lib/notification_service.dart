import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  Future<void> showNotification(String joke) async {
    var android = AndroidNotificationDetails(
      'channel_id',
      'channel_name',
      importance: Importance.high,
      priority: Priority.high,
    );
    var platform = NotificationDetails(android: android);
    await flutterLocalNotificationsPlugin.show(
        0, 'Joke of the Day', joke, platform);
  }

  // Овде може да се додадат други функции за конфигурирање на нотификациите.
}
