import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'notification_service.dart'; // Импортирајте го NotificationService

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;
  final NotificationService _notificationService = NotificationService();

  // Листа со шеги
  final List<String> jokes = [
    "Why don’t scientists trust atoms? Because they make up everything!",
    "Why did the scarecrow win an award? He was outstanding in his field!",
    // Додајте повеќе шеги ако сакате
  ];

  // Функција за додавање на шега во омилени
  Future<void> _addToFavorites(String joke) async {
    final prefs = await SharedPreferences.getInstance();
    List<String> favorites = prefs.getStringList('favorites') ?? [];
    if (!favorites.contains(joke)) {
      favorites.add(joke);
      await prefs.setStringList('favorites', favorites);
      print('Added to favorites: $joke');
    } else {
      print('Already in favorites: $joke');
    }
  }

  // Функција за подесување на Firebase Messaging
  Future<void> _setupFirebaseMessaging() async {
    NotificationSettings settings =
        await _firebaseMessaging.requestPermission();
    print("User granted permission: ${settings.authorizationStatus}");

    // Пријавете се за примање нотификации
    String? token = await _firebaseMessaging.getToken();
    print("FCM Token: $token");

    // Логика за примање на нотификации
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      print(
          'Message received: ${message.notification?.title}, ${message.notification?.body}');
    });
  }

  @override
  void initState() {
    super.initState();
    _setupFirebaseMessaging(); // Повикај ја функцијата за подесување на FCM
    _notificationService.showNotification(
        "Here's a funny joke!"); // Покажи локална нотификација
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Jokes App"),
      ),
      body: ListView.builder(
        itemCount: jokes.length,
        itemBuilder: (context, index) {
          return Card(
            child: ListTile(
              title: Text(jokes[index]),
              trailing: IconButton(
                icon: Icon(Icons.favorite_border),
                onPressed: () {
                  _addToFavorites(jokes[index]); // Додавање на шега во омилени
                },
              ),
            ),
          );
        },
      ),
    );
  }
}
